from bottle import route, run, template
from pack.bib import metros_para_centimetros
from pack.bib import calcula_salario
from pack.bib import calcula_multa

@route('/hello/<name>')
def index(name):
    name = 'bbbb'
    return template('<b>Hello {{name}}</b>!', name=name)

@route("/ex1/<metros:float>")
def route_ex1(metros):
        cm = metros_para_centimetros(metros)
        return template('{{cm}}', cm=cm)

@route("/ex2/<h:float>/<v:float>")
def route_ex2(h, v):
    salario = calcula_salario(h, v)
    return template('Salario: R${{valor}}', valor=salario)

@route('/ex5/<peso:float>')
def route_ex5(peso):
    multa=calcula_multa
    return template('{{texto}}', texto=multa)

run(host='localhost', port=8081)