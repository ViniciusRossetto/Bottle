


def calcula_multa(kg_peixes):
    limite =30
    kg_multa = 3
    excesso = kg_peixes - limite
    if excesso > 0:
        valor = kg_multa * excesso
        return f'Valor multa: R${valor:.2f}'
    else:
        return 'sem multa'


def ex5():
    kg_peixes = float(input('Digite o peso dos peixes '))
    texto = calcula_multa(kg_peixes)
    print(texto)
    