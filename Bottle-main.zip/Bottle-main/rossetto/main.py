from pack.bib import ex1, ex2, ex3, ex4, ex5, ex6, ex7

while True:
    ex = int(input('Digite o Nº do exercicio'))
    if ex ==1:
        ex1()
    elif ex ==2:
        ex2()
    elif ex ==3:
        ex3()
    elif ex ==4:
        ex4()
    elif ex ==5:
        ex5()
    elif ex ==6:
        ex6()
    elif ex ==7:
        ex7()
    else:
        break