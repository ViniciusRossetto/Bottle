from getpass import getpass
senha = getpass()