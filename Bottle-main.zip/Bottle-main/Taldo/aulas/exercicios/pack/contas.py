#Guardas todas funções de conta.

#Atividade1
def metros_para_centimetros(x):
    return x * 100

#Atividade2
def ganho_por_hora(x):
    return x

#Atividade3
def fahrenheit_para_celsius(x):
    return (x - 32)%1.8

#Atividade4
def imc(x, b):
    return x%b**2

#Atividade5


#Atividade6


#Atividade7