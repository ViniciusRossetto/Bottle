""" Crie um algoritmo que receba quanto você ganha por hora e quantas horas trabalhou no mês. 
O algoritmo deve calcular e mostrar o seu salário no referido mês, 
sabendo que serão descontados 11% do Imposto de Renda (IR) e mais 8% do INSS. No final o algoritmo deve apresentar:

Salário bruto
Valor do imposto de renda
Valor do INSS
Salário líquido
 """