def soma_com_dois(x):
    return x + 2
def multiplica_por_dois(x):
    return x * 2