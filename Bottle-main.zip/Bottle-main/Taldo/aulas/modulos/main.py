""" from bib import soma_com_dois  """

""" from pack import bib
valor = float(input('Digite um número: '))
resultado = bib.soma_com_dois(valor)
print(resultado)

valor = float(input('Digite um número: '))
resultado = bib.multiplica_por_dois(valor)
print(resultado) """

""" from pack.bib import *
valor = float(input('Digite um número: '))
resultado = soma_com_dois(valor)
print(resultado)

valor = float(input('Digite um número: '))
resultado = multiplica_por_dois(valor)
print(resultado) """